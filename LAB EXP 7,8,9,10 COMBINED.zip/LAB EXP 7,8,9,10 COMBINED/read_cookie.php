<?php

echo "Cookie value is: ".$_COOKIE["username"];

?>