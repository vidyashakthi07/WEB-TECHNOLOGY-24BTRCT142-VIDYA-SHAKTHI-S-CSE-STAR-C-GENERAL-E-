<?php

$name = $_POST["name"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$message = $_POST["message"];

if(empty($name) || empty($email))
{
echo "Please fill all required fields";
}

elseif(!filter_var($email, FILTER_VALIDATE_EMAIL))
{
echo "Invalid Email format";
}

else
{
echo "<h2>Form Submitted Successfully</h2>";

echo "Name: ".$name."<br>";
echo "Email: ".$email."<br>";
echo "Phone: ".$phone."<br>";
echo "Message: ".$message;
}

?>