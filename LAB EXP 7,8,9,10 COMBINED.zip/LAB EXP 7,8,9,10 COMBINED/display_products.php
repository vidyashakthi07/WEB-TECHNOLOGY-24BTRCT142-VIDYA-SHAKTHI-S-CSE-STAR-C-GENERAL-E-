<?php

$conn = new mysqli("localhost","root","","vdstore");

$sql = "SELECT * FROM products";

$result = $conn->query($sql);

echo "<h2>Product List</h2>";

echo "<table border='1' cellpadding='10'>

<tr>
<th>ID</th>
<th>Name</th>
<th>Price</th>
<th>Description</th>
</tr>";

while($row = $result->fetch_assoc())
{

echo "<tr>";

echo "<td>".$row["id"]."</td>";

echo "<td>".$row["name"]."</td>";

echo "<td>".$row["price"]."</td>";

echo "<td>".$row["description"]."</td>";

echo "</tr>";

}

echo "</table>";

$conn->close();

?>