<?php

session_start();

$username = $_POST["username"];

$_SESSION["user"] = $username;

echo "Login successful";

echo "<br><a href='welcome.php'>Go to Welcome Page</a>";

?>