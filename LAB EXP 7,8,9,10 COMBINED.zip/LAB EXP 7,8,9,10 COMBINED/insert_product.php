<?php

$conn = new mysqli("localhost","root","","vdstore");

if($conn->connect_error)
{
die("Connection failed");
}

$name = $_POST["name"];
$price = $_POST["price"];
$description = $_POST["description"];

$sql = "INSERT INTO products(name,price,description)
VALUES('$name','$price','$description')";

if($conn->query($sql)==TRUE)
{
echo "Product stored successfully";
}
else
{
echo "Error inserting data";
}

$conn->close();

?>