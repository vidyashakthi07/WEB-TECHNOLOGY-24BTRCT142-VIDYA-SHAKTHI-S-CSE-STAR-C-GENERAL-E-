<?php

setcookie("username","Vidya",time()+3600);

echo "Cookie created";

echo "<br><a href='read_cookie.php'>Read Cookie</a>";

?>