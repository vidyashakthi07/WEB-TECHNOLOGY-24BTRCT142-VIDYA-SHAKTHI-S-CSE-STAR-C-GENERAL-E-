<?php

session_start();

echo "<h2>Welcome ".$_SESSION["user"]."</h2>";

echo "<br>Session is working successfully";

?>