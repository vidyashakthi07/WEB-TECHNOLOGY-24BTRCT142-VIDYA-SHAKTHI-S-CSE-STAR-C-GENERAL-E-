<?php

$conn = new mysqli("localhost","root","","vdstore");

if($conn->connect_error)
{
die("Connection failed");
}

$sql = "SELECT * FROM products";

$result = $conn->query($sql);

?>

<html>

<head>

<title>View Products</title>

<link rel="stylesheet" href="style.css">

</head>

<body>

<center>

<h2>Vidya Online Store</h2>

<a href="index.html">Home</a> |
<a href="products.html">Products</a> |
<a href="contact.html">Contact</a> |
<a href="product_form.html">Add Product</a> |
<a href="display_products.php">View Products</a> |
<a href="login.html">Login</a> |
<a href="cookie.php">Cookie Demo</a>

</center>

<hr>

<h2>Product List</h2>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Name</th>
<th>Price</th>
<th>Description</th>
</tr>

<?php

while($row = $result->fetch_assoc())
{

echo "<tr>";

echo "<td>".$row["id"]."</td>";

echo "<td>".$row["name"]."</td>";

echo "<td>".$row["price"]."</td>";

echo "<td>".$row["description"]."</td>";

echo "</tr>";

}

$conn->close();

?>

</table>

<br>

<a href="index.html">Back to Home</a>

</body>

</html>