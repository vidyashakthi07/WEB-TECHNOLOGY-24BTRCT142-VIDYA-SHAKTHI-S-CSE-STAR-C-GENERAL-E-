<?php

session_start();

$username = $_POST["username"];

$_SESSION["user"] = $username;

echo "<h2>Login successful</h2>";

echo "<br><a href='welcome.php'>Go to Welcome Page</a>";

echo "<br><a href='index.html'>Go to Home</a>";

?>