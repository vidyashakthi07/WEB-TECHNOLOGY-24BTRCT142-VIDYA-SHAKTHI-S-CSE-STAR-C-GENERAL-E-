<?php

session_start();

echo "<h2>Welcome ".$_SESSION["user"]."</h2>";

echo "<br>Session working successfully";

echo "<br><a href='index.html'>Back to Home</a>";

?>